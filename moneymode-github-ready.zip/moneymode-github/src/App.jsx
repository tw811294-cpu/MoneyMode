import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import Landing from './pages/Landing';
import About from './pages/About';
import Contact from './pages/Contact';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Transactions from './pages/Transactions';
import Goals from './pages/Goals';
import Budgets from './pages/Budgets';
import Reports from './pages/Reports';
import Challenges from './pages/Challenges';
import Survey from './pages/Survey';
import Recurring from './pages/Recurring';
import Calendar from './pages/Calendar';
import Forecast from './pages/Forecast';
import Scanner from './pages/Scanner';
import Achievements from './pages/Achievements';
import Learn from './pages/Learn';
import Coach from './pages/Coach';
import Settings from './pages/Settings';
import ParentView from './pages/ParentView';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/onboarding" element={<Onboarding />} />
      <Route path="/app" element={<Dashboard />} />
      <Route path="/app/transactions" element={<Transactions />} />
      <Route path="/app/goals" element={<Goals />} />
      <Route path="/app/budgets" element={<Budgets />} />
      <Route path="/app/reports" element={<Reports />} />
      <Route path="/app/challenges" element={<Challenges />} />
      <Route path="/app/survey" element={<Survey />} />
      <Route path="/app/recurring" element={<Recurring />} />
      <Route path="/app/calendar" element={<Calendar />} />
      <Route path="/app/forecast" element={<Forecast />} />
      <Route path="/app/scanner" element={<Scanner />} />
      <Route path="/app/achievements" element={<Achievements />} />
      <Route path="/app/learn" element={<Learn />} />
      <Route path="/app/coach" element={<Coach />} />
      <Route path="/app/settings" element={<Settings />} />
      <Route path="/parent/:code" element={<ParentView />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App